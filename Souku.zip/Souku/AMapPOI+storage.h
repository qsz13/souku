//
//  AMapPOI+storage.h
//  Souku
//
//  Created by Daniel Qiu on 2/7/14.
//  Copyright (c) 2014 zdwx. All rights reserved.
//

#import <AMapSearchKit/AMapCommonObj.h>

@interface AMapPOI (storage)<NSCoding>

@end
