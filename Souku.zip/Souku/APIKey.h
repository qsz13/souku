//
//  APIKey.h
//  Souku
//
//  Created by Daniel Qiu on 2/1/14.
//  Copyright (c) 2014 zdwx. All rights reserved.
//

#ifndef Souku_APIKey_h
#define Souku_APIKey_h

const static NSString *APIKey = @"cf4445eb09d9221fb7edaa09a048daa9";

#endif
