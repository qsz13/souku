//
//  DeepContentViewController.h
//  OfficialDemo3D
//
//  Created by xiaoming han on 13-11-27.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapCommonObj.h>

@interface DeepContentViewController : UIViewController

@property (nonatomic, strong) AMapDeepContent *deepContent;

@end

