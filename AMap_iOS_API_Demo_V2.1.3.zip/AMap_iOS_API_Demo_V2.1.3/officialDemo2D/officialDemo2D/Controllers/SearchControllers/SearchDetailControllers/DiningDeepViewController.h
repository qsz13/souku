//
//  DiningDeepViewController.h
//  OfficialDemo3D
//
//  Created by xiaoming han on 13-12-9.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AMapSearchKit/AMapSearchAPI.h>

@interface DiningDeepViewController : UIViewController

@property (nonatomic, strong) AMapDiningDeepContent *deepDining;

@end
