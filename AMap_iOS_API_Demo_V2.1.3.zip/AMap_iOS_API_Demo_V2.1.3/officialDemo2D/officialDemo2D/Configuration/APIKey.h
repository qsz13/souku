//
//  APIKey.h
//  SearchV3Demo
//
//  Created by songjian on 13-8-14.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#ifndef SearchV3Demo_APIKey_h
#define SearchV3Demo_APIKey_h

/* 使用高德SearchV3, 请首先注册APIKey, 注册APIKey请参考 http://api.amap.com
 */

const static NSString *APIKey = @"";

#endif
