//
//  MATypes.h
//  MAMapKitDemo
//
//  Created by songjian on 12-12-24.
//  Copyright (c) 2012年 songjian. All rights reserved.
//

#import <Foundation/Foundation.h>

enum {
    MAMapTypeStandard = 0,
    MAMapTypeSatellite,
};
typedef NSUInteger MAMapType;
