//
//  AppDelegate.h
//  3DOfficialDemo
//
//  Created by songjian on 13-9-5.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
