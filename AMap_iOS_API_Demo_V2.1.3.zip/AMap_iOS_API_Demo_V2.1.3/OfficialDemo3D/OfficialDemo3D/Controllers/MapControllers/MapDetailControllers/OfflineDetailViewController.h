//
//  OfflineDetailViewController.h
//  Category_demo
//
//  Created by songjian on 13-7-9.
//  Copyright (c) 2013年 songjian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MAMapKit/MAMapKit.h>

@interface OfflineDetailViewController : UIViewController

@property (nonatomic, strong) MAMapView *mapView;

@end
